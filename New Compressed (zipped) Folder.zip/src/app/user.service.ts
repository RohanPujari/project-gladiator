import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Service } from './service';




@Injectable({
  providedIn: 'root'
})
export class UserService {
  constructor(private http:HttpClient) {}
  baseUrl:string = 'http://localhost:9091/';
  createUser(user: Service){
    return this.http.post(this.baseUrl, user);
  }


}












