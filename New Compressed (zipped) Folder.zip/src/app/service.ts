export class Service {
  
    state:string;
    instituteName: string;
    instituteCode:number;
    diseCode: number;
    universityState: string;
    universityName: string;
    setPassword: string;
    confirmPassword: string
}
