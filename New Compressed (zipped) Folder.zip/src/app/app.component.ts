import { Component } from '@angular/core';
import { FormBuilder , Validator} from '@angular/forms'; 

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'institute-reg';
  constructor(private fb:FormBuilder){}
  registrationForm= this.fb.group({
    
  })
}
